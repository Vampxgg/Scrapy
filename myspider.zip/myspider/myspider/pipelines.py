# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
from itemadapter import ItemAdapter

# 存入MongoDB数据库
import pymongo
from .items import New_houseItem, Old_houseItem


class MongodbPipline(object):
    def __init__(self):
        # 建立数据库连接
        client = pymongo.MongoClient('127.0.0.1', 27017)
        # 连接所需数据库， fangzi为数据库名字
        db = client['fangzi']
        # 连接所用集合，也就是通常所说的表，newhouse为表名
        self.post_newhouse = db['newhouse3']  # 新房
        self.post_oldhouse = db['oldhouse3']  # 二手房

    def process_item(self, item, spider):
        if isinstance(item, New_houseItem):
            # 把item转化为字典形式
            postItem = dict(item)
            # 向数据库插入一条记录
            print(postItem)
            self.post_newhouse.insert_one(postItem)
        if isinstance(item, Old_houseItem):
            # 把item转化为字典形式
            postItem = dict(item)
            # 向数据库插入一条记录
            print(postItem)
            self.post_oldhouse.insert_one(postItem)
