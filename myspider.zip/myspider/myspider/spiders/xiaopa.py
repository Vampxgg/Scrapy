import scrapy

class XiaopaSpider(scrapy.Spider):
    name = 'xiaopa'
    allowed_domains = ['https://www.bilibili.com/']
    start_urls = [f'https://search.bilibili.com/all?keyword=python%20scrapy&page=']

    def parse(self, response):
        text=response.xpath('//*[@id="all-list"]/div[1]/div[2]/ul/li[*]/div/div[1]/a/text()').get()
        print(text)
        yield text
        pass
