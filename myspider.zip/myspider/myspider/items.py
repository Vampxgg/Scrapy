# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy


class New_houseItem(scrapy.Item):
    #省
    province=scrapy.Field()
    #城市
    city=scrapy.Field()
    #小区
    name=scrapy.Field()
    #价格
    price=scrapy.Field()
    #几居
    rooms=scrapy.Field()
    #面积
    area=scrapy.Field()
    #行政区
    district=scrapy.Field()
    #有没有正在销售
    sale=scrapy.Field()
    #房子详情url
    new_url=scrapy.Field()

class Old_houseItem(scrapy.Item):
    # 省份
    province = scrapy.Field()
    # 城市
    city = scrapy.Field()
    # 小区名字
    name = scrapy.Field()
    # 地址
    address = scrapy.Field()
    # 总价
    price = scrapy.Field()
    # 单价
    unit = scrapy.Field()
    # 原始的url
    old_url = scrapy.Field()
    # 信息
    infos = scrapy.Field()
